# RLM local companion

Requires Python 3.10+ and Codex CLI installed and signed in with ChatGPT.
Unzip this folder, open a terminal inside it, then run:

    python3 -m venv .venv
    source .venv/bin/activate
    python -m pip install -e '.[visualizer]'
    codex login
    python examples/serve_codex_comparison.py

On Windows, activate with .venv\Scripts\activate instead.
Open https://recursive-llm-lab.sakhli.chatgpt.site, click Connect Codex,
and paste the pairing code printed in your terminal. Keep the terminal open.
Select a document, review the question, then click Download & run.

No experiment runs until you request it. Model calls use your Codex subscription.
Files are processed by this local companion and sent through Codex to the model.
Raw prompts and results are retained in the output folder shown by the companion.
The included presets contain URLs and reference metadata, not document contents.
Stop the companion with Ctrl+C. Never share its pairing code.

Source: https://github.com/grishahq/recursive-llm (MIT)
SOURCE_MANIFEST.json contains a SHA-256 for each bundled source file.
